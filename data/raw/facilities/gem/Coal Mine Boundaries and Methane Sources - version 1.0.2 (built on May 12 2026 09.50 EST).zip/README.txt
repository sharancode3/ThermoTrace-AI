This README describes the contents of version Coal Mine Boundaries and Methane Sources - version 1.0.2 (built on May 12 2026 09.50 EST) of the ZIP file 

1. Spreadsheet files

   a) All research results across all mines:
   
        Coal Mine Boundaries and Methane Sources - version 1.0.2 (built on May 12 2026 09.50 EST).xlsx
      
   b) Research results for each mine:

        <mine name>.xlsx

2. GeoJSON files

   a) All research results across all mines:

        Coal Mine Boundaries and Methane Sources - version 1.0.2 (built on May 12 2026 09.50 EST).geojson

   b) Research results for each mine:

        <mine name>.geojson

Please contact dominic.nicholas@globalenergymonitor.org with any questions, suggestions or feedback.

Thanks

